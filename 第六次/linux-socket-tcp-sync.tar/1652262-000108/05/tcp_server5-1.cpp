#include <fcntl.h>
#include <stdio.h>
#include <errno.h>
#include <iostream>
#include <unistd.h>
#include <string.h>
#include <stdlib.h>
#include <sys/shm.h>
#include <sys/types.h>
#include <arpa/inet.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <netinet/in.h>
using namespace std;
int main(int argc, char* argv[])
{
	int server_sockfd = socket(AF_INET, SOCK_STREAM, 0);
	int enable = 1;	
	int port = atoi(argv[1]);	
	char string_temp[50000];
	struct sockaddr_in client_addr;
	struct sockaddr_in server_sockaddr;
	if (setsockopt(server_sockfd, SOL_SOCKET, SO_REUSEADDR, &enable, sizeof(int)) < 0)
	{
		perror("setsockopt(SO_REUSEADDR) failed");
	}
	server_sockaddr.sin_family = AF_INET;
	server_sockaddr.sin_port = htons(port);
	server_sockaddr.sin_addr.s_addr = htonl(INADDR_ANY);
	if (bind(server_sockfd, (struct sockaddr *)&server_sockaddr, sizeof(server_sockaddr)) == -1)
	{
		perror("bind");
		exit(1);
	}
	if (listen(server_sockfd, 20) == -1)
	{
		perror("listen");
		exit(1);
	}
	socklen_t length = sizeof(client_addr);
	int connection = accept(server_sockfd, (struct sockaddr*)&client_addr, &length);
	if (connection < 0)
	{
		perror("connect");
		exit(1);
	}
	else
		cout << "��ͻ������ӳɹ�!" << endl;
	getchar();
	while (1)
	{
		memset(string_temp, 0, sizeof(string_temp));
		read(connection, string_temp, sizeof(string_temp));
		if (strcmp(string_temp, "exit\n") == 0)
			break;
	}
	close(connection);
	close(server_sockfd);
	return 0;
}